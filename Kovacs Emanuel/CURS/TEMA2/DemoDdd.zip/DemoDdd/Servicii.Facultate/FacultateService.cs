﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Servicii.Facultate
{
    public class FacultateService
    {
        public void TransmiteMediiMultiAnualeCatreCamine(string numeFacultate)
        {
            //cauta facultatea

            //incarca model camine

            //actualizeaza medii multi anuale in model camine

            //salveaza
        }
    }
}
