﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace Modele.Orar
{
    public class Grupa
    {
        private int _grupa;
        public int GrupaFacultate { get { return _grupa; } }

        internal Grupa(int grupa)
        {
            Contract.Requires<ArgumentException>(grupa > 0, "grupa");
            Contract.Requires<ArgumentException>(grupa < 10, "grupa");
            _grupa = grupa;
        }

        #region override object
        public override bool Equals(object obj)
        {
            var grupa = (Grupa)obj;
            return grupa._grupa == _grupa;
        }

        public override int GetHashCode()
        {
            return GrupaFacultate.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}", _grupa);
        }
        #endregion
    }
}
