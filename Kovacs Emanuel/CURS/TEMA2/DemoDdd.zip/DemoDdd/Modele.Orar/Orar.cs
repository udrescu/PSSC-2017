﻿using Modele.Generic;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace Modele.Orar
{
    class Orar
    {
        public PlainText Facultate { get; internal set; }
        public PlainText Specializare { get; internal set; }
        public An AnFacultate { get; internal set; }
        public Semenstru Semestru { get; internal set; }
        public PlainText Laborator { get; internal set; }
        public PlainText Curs { get; internal set; }
        public PlainText Sala { get; internal set; }
        public PlainText Profesor { get; internal set; }

        public List<Grupa> _grupeAn;

        internal Orar(PlainText faculate, PlainText specializare, An an, Semenstru semestru, PlainText laborator,PlainText curs,PlainText sala,PlainText profesor)
        {
            Contract.Requires(faculate != null, "faculate");
            Contract.Requires(specializare != null, "specializare");
            Contract.Requires(an != null, "an");
            Contract.Requires(semestru != null, "semestru");
            Contract.Requires(laborator != null, "laborator");
            Contract.Requires(curs != null, "curs");
            Contract.Requires(sala != null, "sala");
            Contract.Requires(profesor != null, "profesor");
            Facultate = faculate;
            Specializare = specializare;
            AnFacultate = an;
            Semestru = semestru;
            Laborator = laborator;
            Curs = curs;
            Sala = sala;
            Profesor = profesor;
        }

        internal Orar(PlainText faculate, PlainText specializare, An an, Semenstru semestru, PlainText laborator, PlainText curs, PlainText sala, PlainText profesor, List<Grupa> grupeAn)
            :this(faculate, specializare, an, semestru, laborator, curs, sala, profesor)
        {
            Contract.Requires(grupeAn != null, "grupe an");
            _grupeAn = grupeAn;
        }

        #region operatii
        public void AdaugaGrupa(Grupa grupa)
        {
            Contract.Requires(grupa != null, "grupa");

            var gasit = _grupeAn.FirstOrDefault(s => s.Equals(grupa));
            if (gasit == null)
            {
                _grupeAn.Add(grupa);
            }
            else
            {
                throw new GrupaExistaExceptions();
            }
        }

        /*public void IncepeSemestru()
        {
            Contract.Requires(Stare == StareDisciplina.Inscrieri, "nu suntem in perioada in care se fac inscrieri");
            Stare = StareDisciplina.InDesfasurare;
        }

        public void IncheieSemestru()
        {
            Contract.Requires(Stare == StareDisciplina.InDesfasurare, "semestrul nu a inceput");

            //calculeaza nota finala
            //BUG: metoda poate arunca exceptii daca studentii nu au toate notele, 
            //ar trebui refactorizat sa permita ca anumiti studenti sa nu poata fi incheiati
            foreach (var student in _studentiInscrisi)
            {
                student.CalculeazaNotaFinala(PondereExamen);
            }
            Stare = StareDisciplina.Incheiata;
        }

        public void NoteazaActivitateStudent(NumarMatricol nrMatricolStudent, Nota nota)
        {
            Contract.Requires(nrMatricolStudent != null);
            Contract.Requires(nota != null);
            Contract.Requires(Stare == StareDisciplina.InDesfasurare, "semestrul nu a inceput");

            var student = _studentiInscrisi.First(s => s.NumarMatricol.Equals(nrMatricolStudent));
            student.NoteActivitate.AdaugaNota(nota);
        }

        public void TreceNoteExamen(Dictionary<NumarMatricol, Nota> rezultateExamen)
        {
            Contract.Requires(rezultateExamen != null);
            Contract.Requires(Stare == StareDisciplina.InDesfasurare, "semestrul nu a inceput");
            foreach (var pair in rezultateExamen)
            {
                var student = _studentiInscrisi.First(s => s.NumarMatricol.Equals(pair.Key));
                student.NotaExamen = pair.Value;
            }
        }

        public void IncarcaMaterialCurs(PlainText numeCurs, Uri continutCurs)
        {
            Contract.Requires(numeCurs != null, "numeCurs");
            Contract.Requires(continutCurs != null, "continutCurs");
            var curs = Cursuri.Valori.FirstOrDefault(c => c.Nume.Equals(numeCurs));
            if (curs == null)
            {
                //cursul trebuie creat
                curs = new Curs(numeCurs);
                curs.LinkContinut = continutCurs;
                Cursuri.AdaugaCurs(curs);
            }
            else
            {
                //cursul exista
                curs.ActualizareLinkContinut(continutCurs);
            }
        }

        public void IncarcaMaterialLaborator(PlainText numeLaborator, Uri continutLaborator)
        {
            Contract.Requires(numeLaborator != null, "numeLaborator");
            Contract.Requires(continutLaborator != null, "continutLaborator");
            var laborator = Laboratoare.Valori.FirstOrDefault(c => c.Nume.Equals(numeLaborator));
            if (laborator == null)
            {
                //Laboratorul trebuie creat
                laborator = new Laborator(numeLaborator);
                laborator.LinkContinut = continutLaborator;
                Laboratoare.AdaugaLaborator(laborator);
            }
            else
            {
                //Laboratorul exista
                laborator.ActualizareLinkContinut(continutLaborator);
            }
        }*/
        #endregion

        #region override object
        public override string ToString()
        {
            return "Orar "+Facultate.ToString()+" "+Specializare.ToString()+" "+AnFacultate.ToString();
        }

        public override bool Equals(object obj)
        {
            var orar = (Orar)obj;

            if (orar != null)
            {
                return Facultate.Equals(orar.Facultate) && Specializare.Equals(orar.Specializare) && AnFacultate.Equals(orar.AnFacultate);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Facultate.GetHashCode();
        }
        #endregion
    }
}
