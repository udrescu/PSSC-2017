﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace Modele.Generic
{
    public class Semenstru
    {
        private int _semestru;
        public int SemestruFacultate { get { return _semestru; } }

        internal Semenstru(int semestru)
        {
            Contract.Requires<ArgumentException>((semestru == 1) || (semestru == 2), "semestrul 1 sau semestrul 2");
            _semestru = semestru;

        }
        #region override object
        public override bool Equals(object obj)
        {
            var semestru = (Semenstru)obj;
            return semestru._semestru == _semestru;
        }

        public override int GetHashCode()
        {
            return SemestruFacultate.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}", _semestru);
        }
        #endregion
    }
}
