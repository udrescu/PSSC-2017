﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace Modele.Generic
{
    public class AniFacultate
    {
        private int _nrAniFacultate;
        public int NrAniFacultate { get { return _nrAniFacultate; } }

        internal AniFacultate(int nr)
        {
            Contract.Requires<ArgumentException>((nr == 3) || (nr == 4) || (nr == 6), "numar ani facultate");
            _nrAniFacultate = nr;
        }

        #region override object
        public override bool Equals(object obj)
        {
            var nrAni = (AniFacultate)obj;
            return nrAni._nrAniFacultate == _nrAniFacultate;
        }

        public override int GetHashCode()
        {
            return NrAniFacultate.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}", _nrAniFacultate);
        }
        #endregion
    }
}

