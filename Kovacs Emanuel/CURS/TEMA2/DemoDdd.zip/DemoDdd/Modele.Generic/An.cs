﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;

namespace Modele.Generic
{
    public class An
    {
        private int _an;
        public int AnFacultate { get { return _an; } }

        internal An(int an, int nrAni)
        {
            AniFacultate ani = new AniFacultate(nrAni);
            Contract.Requires<ArgumentException>(an > 0, "an");
            switch (ani.NrAniFacultate)
            {
                case 3: Contract.Requires<ArgumentException>(an <= 3, "an");
                    break;
                case 4: Contract.Requires<ArgumentException>(an <= 4, "an");
                    break;
                case 6: Contract.Requires<ArgumentException>(an <= 6, "an");
                    break;
                default: break;
            }

            _an = an;
        }

        #region override object
        public override bool Equals(object obj)
        {
            var an = (An)obj;
            return an._an == _an;
        }

        public override int GetHashCode()
        {
            return AnFacultate.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("{0}", _an);
        }
        #endregion
    }
}
